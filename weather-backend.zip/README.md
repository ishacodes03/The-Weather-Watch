# Weather Backend

A small Express server that fetches weather data from OpenWeatherMap securely.

## Usage

- Deploy on Render / Railway / Vercel
- Set API_KEY environment variable in hosting dashboard

### API

GET `/weather?lat={latitude}&lon={longitude}`
Returns weather data as JSON.