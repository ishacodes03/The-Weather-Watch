const express = require("express");
const axios = require("axios");
const cors = require("cors");

const app = express();
app.use(cors());

const PORT = process.env.PORT || 4000;
const API_KEY = process.env.API_KEY;  // this will come from Render env var

app.get("/weather", async (req, res) => {
  const { lat, lon } = req.query;
  if (!lat || !lon) {
    return res.status(400).json({ error: "Missing lat or lon parameters" });
  }

  try {
    const response = await axios.get("https://api.openweathermap.org/data/2.5/weather", {
      params: {
        lat,
        lon,
        units: "metric",
        appid: API_KEY,
      },
    });
    res.json(response.data);
  } catch (err) {
    console.error(err.response ? err.response.data : err.message);
    res.status(500).json({ error: "Weather API failed" });
  }
});

app.get("/", (req, res) => {
  res.send("Weather backend is running.");
});

app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});